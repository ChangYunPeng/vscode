# image-classification

## Models


## Usage
```bassh
$ python3 main.py -m [spatial_net]
```
